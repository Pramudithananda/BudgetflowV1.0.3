import * as SQLite from 'expo-sqlite';

// Database initialization
let db = null;

const initDatabase = async () => {
  if (db) return db;
  
  try {
    db = await SQLite.openDatabaseAsync('budgetflow.db');
    
    // Create tables
    await db.execAsync(`
      PRAGMA journal_mode = WAL;
      
      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        amount REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Outstanding',
        category_id INTEGER,
        funder_id INTEGER,
        event_id INTEGER,
        assigned_to TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL,
        FOREIGN KEY (funder_id) REFERENCES funders (id) ON DELETE SET NULL,
        FOREIGN KEY (event_id) REFERENCES events (id) ON DELETE SET NULL
      );
      
      CREATE TABLE IF NOT EXISTS budget (
        id INTEGER PRIMARY KEY DEFAULT 1,
        total_budget REAL DEFAULT 0,
        received_fund REAL DEFAULT 0,
        people_over_fund REAL DEFAULT 0,
        remaining_fund REAL DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS helpers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS funders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        start_date DATE,
        end_date DATE,
        budget REAL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Planning',
        location TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE INDEX IF NOT EXISTS idx_expenses_category_id ON expenses(category_id);
      CREATE INDEX IF NOT EXISTS idx_expenses_funder_id ON expenses(funder_id);
      CREATE INDEX IF NOT EXISTS idx_expenses_event_id ON expenses(event_id);
      CREATE INDEX IF NOT EXISTS idx_expenses_status ON expenses(status);
      CREATE INDEX IF NOT EXISTS idx_expenses_created_at ON expenses(created_at);
      CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
      CREATE INDEX IF NOT EXISTS idx_events_start_date ON events(start_date);
      
      -- Insert default budget record if not exists
      INSERT OR IGNORE INTO budget (id, total_budget, received_fund, people_over_fund, remaining_fund)
      VALUES (1, 0, 0, 0, 0);
      
      -- Insert default categories if none exist
      INSERT OR IGNORE INTO categories (id, name) VALUES 
        (1, 'Food & Dining'),
        (2, 'Transportation'),
        (3, 'Entertainment'),
        (4, 'Utilities'),
        (5, 'Healthcare'),
        (6, 'Shopping'),
        (7, 'Education'),
        (8, 'Other');
      
      -- Insert default funders if none exist
      INSERT OR IGNORE INTO funders (id, name) VALUES 
        (1, 'Personal Budget'),
        (2, 'Company Fund'),
        (3, 'Project Budget'),
        (4, 'Emergency Fund');
      
      -- Insert default events if none exist
      INSERT OR IGNORE INTO events (id, name, description, budget, status) VALUES 
        (1, 'General Expenses', 'Default event for general expenses', 0, 'Active'),
        (2, 'Wedding Planning', 'Wedding event expenses', 500000, 'Planning'),
        (3, 'Birthday Party', 'Birthday celebration expenses', 50000, 'Planning'),
        (4, 'Office Event', 'Company event expenses', 100000, 'Planning');
    `);
    
    console.log('Database initialized successfully');
    return db;
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
};

// Helper function to ensure database is initialized
const getDatabase = async () => {
  if (!db) {
    await initDatabase();
  }
  return db;
};

// Utility function to convert SQLite row to object with camelCase
const convertRow = (row) => {
  const converted = {};
  for (const [key, value] of Object.entries(row)) {
    const camelKey = key.replace(/_([a-z])/g, (match, letter) => letter.toUpperCase());
    converted[camelKey] = value;
  }
  return converted;
};

// Category Operations
export const getCategories = async () => {
  try {
    const database = await getDatabase();
    const result = await database.getAllAsync('SELECT * FROM categories ORDER BY name');
    console.log('Categories fetched:', result.length, 'items');
    
    // If no categories found, ensure default categories are inserted
    if (result.length === 0) {
      console.log('No categories found, inserting defaults...');
      await database.execAsync(`
        INSERT OR REPLACE INTO categories (id, name) VALUES 
          (1, 'Food & Dining'),
          (2, 'Transportation'),
          (3, 'Entertainment'),
          (4, 'Utilities'),
          (5, 'Healthcare'),
          (6, 'Shopping'),
          (7, 'Education'),
          (8, 'Other');
      `);
      
      // Fetch again after inserting defaults
      const newResult = await database.getAllAsync('SELECT * FROM categories ORDER BY name');
      console.log('Default categories inserted:', newResult.length, 'items');
      return newResult.map(convertRow);
    }
    
    return result.map(convertRow);
  } catch (error) {
    console.error('Error getting categories:', error);
    throw error;
  }
};

export const addCategory = async (categoryData) => {
  try {
    const database = await getDatabase();
    const result = await database.runAsync(
      'INSERT INTO categories (name) VALUES (?)',
      [categoryData.name]
    );
    
    const newCategory = {
      id: result.lastInsertRowId,
      name: categoryData.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Notify listeners
    notifyListeners('categories');
    
    return newCategory;
  } catch (error) {
    console.error('Error adding category:', error);
    throw error;
  }
};

export const updateCategory = async (categoryId, categoryData) => {
  try {
    const database = await getDatabase();
    await database.runAsync(
      'UPDATE categories SET name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [categoryData.name, categoryId]
    );
    
    // Notify listeners
    notifyListeners('categories');
    
    return { id: categoryId, ...categoryData };
  } catch (error) {
    console.error('Error updating category:', error);
    throw error;
  }
};

export const deleteCategory = async (categoryId) => {
  try {
    const database = await getDatabase();
    await database.runAsync('DELETE FROM categories WHERE id = ?', [categoryId]);
    
    // Notify listeners
    notifyListeners('categories');
    
    return categoryId;
  } catch (error) {
    console.error('Error deleting category:', error);
    throw error;
  }
};

// Expense Operations
export const getExpense = async (id) => {
  try {
    const database = await getDatabase();
    const result = await database.getFirstAsync('SELECT * FROM expenses WHERE id = ?', [id]);
    
    if (!result) {
      return null;
    }
    
    return convertRow(result);
  } catch (error) {
    console.error('Error getting expense:', error);
    throw error;
  }
};

export const getExpenses = async (categoryId = null) => {
  try {
    const database = await getDatabase();
    let query = 'SELECT * FROM expenses';
    let params = [];
    
    if (categoryId) {
      query += ' WHERE category_id = ?';
      params = [categoryId];
    }
    
    query += ' ORDER BY created_at DESC';
    
    const result = await database.getAllAsync(query, params);
    return result.map(convertRow);
  } catch (error) {
    console.error('Error getting expenses:', error);
    throw error;
  }
};

// Data change listeners for SQLite
const listeners = {
  expenses: new Set(),
  categories: new Set(),
  funders: new Set(),
  events: new Set(),
};

// Helper function to notify listeners of data changes
const notifyListeners = async (type, categoryId = null) => {
  const relevantListeners = Array.from(listeners[type]).filter(listener => {
    if (type === 'expenses' && categoryId !== null) {
      return listener.categoryId === categoryId || listener.categoryId === null;
    }
    return true;
  });

  for (const listener of relevantListeners) {
    try {
      let data;
      switch (type) {
        case 'expenses':
          data = await getExpenses(listener.categoryId);
          break;
        case 'categories':
          data = await getCategories();
          break;
        case 'funders':
          data = await getFunders();
          break;
        case 'events':
          data = await getEvents();
          break;
      }
      listener.callback(data);
    } catch (error) {
      console.error(`Error notifying ${type} listener:`, error);
    }
  }
};

export const listenExpenses = (categoryId = null, callback) => {
  const listener = { categoryId, callback };
  listeners.expenses.add(listener);
  
  // Initial data fetch
  const fetchAndNotify = async () => {
    try {
      const expenses = await getExpenses(categoryId);
      callback(expenses);
    } catch (error) {
      console.error('Error in listenExpenses:', error);
    }
  };
  
  fetchAndNotify();
  
  // Return cleanup function
  return () => {
    listeners.expenses.delete(listener);
  };
};

export const listenCategories = (callback) => {
  const listener = { callback };
  listeners.categories.add(listener);
  
  const fetchAndNotify = async () => {
    try {
      const categories = await getCategories();
      callback(categories);
    } catch (error) {
      console.error('Error in listenCategories:', error);
    }
  };
  
  fetchAndNotify();
  
  return () => {
    listeners.categories.delete(listener);
  };
};

export const listenFunders = (callback) => {
  const listener = { callback };
  listeners.funders.add(listener);
  
  const fetchAndNotify = async () => {
    try {
      const funders = await getFunders();
      callback(funders);
    } catch (error) {
      console.error('Error in listenFunders:', error);
    }
  };
  
  fetchAndNotify();
  
  return () => {
    listeners.funders.delete(listener);
  };
};

export const addExpense = async (expenseData) => {
  try {
    const database = await getDatabase();
    const result = await database.runAsync(
      'INSERT INTO expenses (title, amount, status, category_id, funder_id, assigned_to) VALUES (?, ?, ?, ?, ?, ?)',
      [
        expenseData.title,
        expenseData.amount || 0,
        expenseData.status || 'Outstanding',
        expenseData.categoryId || null,
        expenseData.funderId || null,
        expenseData.assignedTo || null
      ]
    );
    
    const newExpense = {
      id: result.lastInsertRowId,
      title: expenseData.title,
      amount: expenseData.amount || 0,
      status: expenseData.status || 'Outstanding',
      categoryId: expenseData.categoryId || null,
      funderId: expenseData.funderId || null,
      assignedTo: expenseData.assignedTo || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Notify listeners
    notifyListeners('expenses', expenseData.categoryId);
    
    return newExpense;
  } catch (error) {
    console.error('Error adding expense:', error);
    throw error;
  }
};

export const updateExpense = async (expenseId, expenseData) => {
  try {
    const database = await getDatabase();
    await database.runAsync(
      'UPDATE expenses SET title = ?, amount = ?, status = ?, category_id = ?, funder_id = ?, assigned_to = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [
        expenseData.title,
        expenseData.amount,
        expenseData.status,
        expenseData.categoryId || null,
        expenseData.funderId || null,
        expenseData.assignedTo || null,
        expenseId
      ]
    );
    
    // Notify listeners
    notifyListeners('expenses', expenseData.categoryId);
    
    return { id: expenseId, ...expenseData };
  } catch (error) {
    console.error('Error updating expense:', error);
    throw error;
  }
};

export const deleteExpense = async (expenseId) => {
  try {
    const database = await getDatabase();
    await database.runAsync('DELETE FROM expenses WHERE id = ?', [expenseId]);
    
    // Notify listeners
    notifyListeners('expenses');
    
    return expenseId;
  } catch (error) {
    console.error('Error deleting expense:', error);
    throw error;
  }
};

// Budget Operations
export const getBudgetSummary = async () => {
  try {
    const database = await getDatabase();
    const result = await database.getFirstAsync('SELECT * FROM budget WHERE id = 1');
    
    if (result) {
      return convertRow(result);
    } else {
      // Create default budget if not exists
      const defaultBudget = {
        totalBudget: 0,
        receivedFund: 0,
        peopleOverFund: 0,
        remainingFund: 0,
      };
      
      await updateBudgetSummary(defaultBudget);
      return defaultBudget;
    }
  } catch (error) {
    console.error('Error getting budget summary:', error);
    throw error;
  }
};

export const updateBudgetSummary = async (budgetData) => {
  try {
    const database = await getDatabase();
    await database.runAsync(
      'UPDATE budget SET total_budget = ?, received_fund = ?, people_over_fund = ?, remaining_fund = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1',
      [
        budgetData.totalBudget || 0,
        budgetData.receivedFund || 0,
        budgetData.peopleOverFund || 0,
        budgetData.remainingFund || 0
      ]
    );
    
    return budgetData;
  } catch (error) {
    console.error('Error updating budget summary:', error);
    throw error;
  }
};

// Helper Operations
export const getHelpers = async () => {
  try {
    const database = await getDatabase();
    const result = await database.getAllAsync('SELECT * FROM helpers ORDER BY name');
    return result.map(convertRow);
  } catch (error) {
    console.error('Error getting helpers:', error);
    throw error;
  }
};

export const addHelper = async (helperData) => {
  try {
    const database = await getDatabase();
    const result = await database.runAsync(
      'INSERT INTO helpers (name) VALUES (?)',
      [helperData.name]
    );
    
    const newHelper = {
      id: result.lastInsertRowId,
      name: helperData.name,
      createdAt: new Date().toISOString(),
    };
    
    return newHelper;
  } catch (error) {
    console.error('Error adding helper:', error);
    throw error;
  }
};

// Funder Operations
export const getFunders = async () => {
  try {
    const database = await getDatabase();
    const result = await database.getAllAsync('SELECT * FROM funders ORDER BY name');
    console.log('Funders fetched:', result.length, 'items');
    
    // If no funders found, ensure default funders are inserted
    if (result.length === 0) {
      console.log('No funders found, inserting defaults...');
      await database.execAsync(`
        INSERT OR REPLACE INTO funders (id, name) VALUES 
          (1, 'Personal Budget'),
          (2, 'Company Fund'),
          (3, 'Project Budget'),
          (4, 'Emergency Fund');
      `);
      
      // Fetch again after inserting defaults
      const newResult = await database.getAllAsync('SELECT * FROM funders ORDER BY name');
      console.log('Default funders inserted:', newResult.length, 'items');
      return newResult.map(convertRow);
    }
    
    return result.map(convertRow);
  } catch (error) {
    console.error('Error getting funders:', error);
    throw error;
  }
};

export const addFunder = async (funderData) => {
  try {
    const database = await getDatabase();
    const result = await database.runAsync(
      'INSERT INTO funders (name) VALUES (?)',
      [funderData.name]
    );
    
    const newFunder = {
      id: result.lastInsertRowId,
      name: funderData.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Notify listeners
    notifyListeners('funders');
    
    return newFunder;
  } catch (error) {
    console.error('Error adding funder:', error);
    throw error;
  }
};

export const updateFunder = async (funderId, funderData) => {
  try {
    const database = await getDatabase();
    await database.runAsync(
      'UPDATE funders SET name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [funderData.name, funderId]
    );
    
    // Notify listeners
    notifyListeners('funders');
    
    return { id: funderId, ...funderData };
  } catch (error) {
    console.error('Error updating funder:', error);
    throw error;
  }
};

export const deleteFunder = async (funderId) => {
  try {
    const database = await getDatabase();
    await database.runAsync('DELETE FROM funders WHERE id = ?', [funderId]);
    
    // Notify listeners
    notifyListeners('funders');
    
    return funderId;
  } catch (error) {
    console.error('Error deleting funder:', error);
    throw error;
  }
};

// Event Operations
export const getEvents = async () => {
  try {
    const database = await getDatabase();
    const result = await database.getAllAsync('SELECT * FROM events ORDER BY start_date DESC, created_at DESC');
    console.log('Events fetched:', result.length, 'items');
    
    // If no events found, ensure default events are inserted
    if (result.length === 0) {
      console.log('No events found, inserting defaults...');
      await database.execAsync(`
        INSERT OR REPLACE INTO events (id, name, description, budget, status) VALUES 
          (1, 'General Expenses', 'Default event for general expenses', 0, 'Active'),
          (2, 'Wedding Planning', 'Wedding event expenses', 500000, 'Planning'),
          (3, 'Birthday Party', 'Birthday celebration expenses', 50000, 'Planning'),
          (4, 'Office Event', 'Company event expenses', 100000, 'Planning');
      `);
      
      const newResult = await database.getAllAsync('SELECT * FROM events ORDER BY start_date DESC, created_at DESC');
      console.log('Default events inserted:', newResult.length, 'items');
      return newResult.map(convertRow);
    }
    
    return result.map(convertRow);
  } catch (error) {
    console.error('Error getting events:', error);
    throw error;
  }
};

export const getEvent = async (id) => {
  try {
    const database = await getDatabase();
    console.log('Getting event with ID:', id, 'Type:', typeof id);
    
    const result = await database.getFirstAsync('SELECT * FROM events WHERE id = ?', [id]);
    console.log('Event query result:', result);
    
    if (!result) {
      console.log('No event found with ID:', id);
      // Try to get all events to see what's available
      const allEvents = await database.getAllAsync('SELECT * FROM events');
      console.log('Available events:', allEvents);
      return null;
    }
    
    const converted = convertRow(result);
    console.log('Converted event:', converted);
    return converted;
  } catch (error) {
    console.error('Error getting event:', error);
    throw error;
  }
};

export const addEvent = async (eventData) => {
  try {
    const database = await getDatabase();
    const result = await database.runAsync(
      'INSERT INTO events (name, description, start_date, end_date, budget, status, location) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        eventData.name,
        eventData.description || null,
        eventData.startDate || null,
        eventData.endDate || null,
        eventData.budget || 0,
        eventData.status || 'Planning',
        eventData.location || null
      ]
    );
    
    const newEvent = {
      id: result.lastInsertRowId,
      name: eventData.name,
      description: eventData.description || null,
      startDate: eventData.startDate || null,
      endDate: eventData.endDate || null,
      budget: eventData.budget || 0,
      status: eventData.status || 'Planning',
      location: eventData.location || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Notify listeners
    notifyListeners('events');
    
    return newEvent;
  } catch (error) {
    console.error('Error adding event:', error);
    throw error;
  }
};

export const updateEvent = async (eventId, eventData) => {
  try {
    const database = await getDatabase();
    await database.runAsync(
      'UPDATE events SET name = ?, description = ?, start_date = ?, end_date = ?, budget = ?, status = ?, location = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [
        eventData.name,
        eventData.description || null,
        eventData.startDate || null,
        eventData.endDate || null,
        eventData.budget || 0,
        eventData.status || 'Planning',
        eventData.location || null,
        eventId
      ]
    );
    
    // Notify listeners
    notifyListeners('events');
    
    return { id: eventId, ...eventData };
  } catch (error) {
    console.error('Error updating event:', error);
    throw error;
  }
};

export const deleteEvent = async (eventId) => {
  try {
    const database = await getDatabase();
    await database.runAsync('DELETE FROM events WHERE id = ?', [eventId]);
    
    // Notify listeners
    notifyListeners('events');
    
    return eventId;
  } catch (error) {
    console.error('Error deleting event:', error);
    throw error;
  }
};

export const getExpensesByEvent = async (eventId) => {
  try {
    const database = await getDatabase();
    console.log('Getting expenses for event ID:', eventId);
    
    const result = await database.getAllAsync(
      'SELECT * FROM expenses WHERE event_id = ? ORDER BY created_at DESC',
      [eventId]
    );
    
    console.log('Expenses for event', eventId, ':', result.length, 'items');
    return result.map(convertRow);
  } catch (error) {
    console.error('Error getting expenses by event:', error);
    // Return empty array instead of throwing error
    return [];
  }
};

export const listenEvents = (callback) => {
  const listener = { callback };
  listeners.events.add(listener);
  
  const fetchAndNotify = async () => {
    try {
      const events = await getEvents();
      callback(events);
    } catch (error) {
      console.error('Error in listenEvents:', error);
    }
  };
  
  fetchAndNotify();
  
  return () => {
    listeners.events.delete(listener);
  };
};

// Initialize database when module loads
initDatabase().catch(console.error);

// Debug function to check database state
export const debugDatabase = async () => {
  try {
    const database = await getDatabase();
    const categories = await database.getAllAsync('SELECT * FROM categories');
    const funders = await database.getAllAsync('SELECT * FROM funders');
    console.log('Database Debug:');
    console.log('Categories:', categories);
    console.log('Funders:', funders);
    return { categories, funders };
  } catch (error) {
    console.error('Debug error:', error);
    return { error };
  }
};