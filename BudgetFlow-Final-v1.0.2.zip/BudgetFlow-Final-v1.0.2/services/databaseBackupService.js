import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
// import * as DocumentPicker from 'expo-document-picker'; // Will be added later
import { Alert } from 'react-native';
import { 
  getCategories, 
  getExpenses, 
  getFunders, 
  getHelpers, 
  getBudgetSummary,
  addCategory,
  addExpense,
  addFunder,
  addHelper,
  updateBudgetSummary
} from './sqliteService';

// Export database to JSON file
export const exportDatabase = async () => {
  try {
    console.log('Starting database export...');
    
    // Fetch all data from database
    const [categories, expenses, funders, helpers, budget] = await Promise.all([
      getCategories(),
      getExpenses(),
      getFunders(),
      getHelpers(),
      getBudgetSummary()
    ]);
    
    // Create export object
    const exportData = {
      exportInfo: {
        appName: 'BudgetFlow',
        version: '1.0.0',
        exportDate: new Date().toISOString(),
        developer: 'Ranjith Karunarathne',
        email: 'ranjithpalugolla@gmail.com'
      },
      database: {
        categories: categories,
        expenses: expenses,
        funders: funders,
        helpers: helpers,
        budget: budget
      },
      statistics: {
        totalCategories: categories.length,
        totalExpenses: expenses.length,
        totalFunders: funders.length,
        totalHelpers: helpers.length,
        totalBudget: budget.totalBudget || 0
      }
    };
    
    // Convert to JSON string
    const jsonData = JSON.stringify(exportData, null, 2);
    
    // Create filename with timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
    const filename = `BudgetFlow-Backup-${timestamp}.json`;
    
    // Write to file
    const fileUri = FileSystem.documentDirectory + filename;
    await FileSystem.writeAsStringAsync(fileUri, jsonData);
    
    console.log('Export file created:', fileUri);
    
    // Share the file
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(fileUri, {
        mimeType: 'application/json',
        dialogTitle: 'Export BudgetFlow Database',
        UTI: 'public.json'
      });
    } else {
      Alert.alert(
        'Export Complete',
        `Database exported to: ${filename}\n\nFile saved in app documents folder.`
      );
    }
    
    return {
      success: true,
      filename: filename,
      fileUri: fileUri,
      recordCount: {
        categories: categories.length,
        expenses: expenses.length,
        funders: funders.length,
        helpers: helpers.length
      }
    };
    
  } catch (error) {
    console.error('Export error:', error);
    Alert.alert('Export Failed', 'Could not export database. Please try again.');
    throw error;
  }
};

// Import database from JSON file
export const importDatabase = async () => {
  try {
    console.log('Starting database import...');
    
    // For now, show instructions for manual import
    Alert.alert(
      'Import Instructions',
      'To import data:\n\n' +
      '1. First, export your data from another device\n' +
      '2. Share the JSON file to this device\n' +
      '3. Use "Import from File" option (coming soon)\n\n' +
      'Currently: Manual import via file sharing',
      [{ text: 'OK' }]
    );
    
    return { success: false, message: 'Manual import instructions shown' };
    
    /* TODO: Implement with expo-document-picker
    const result = await DocumentPicker.getDocumentAsync({
      type: 'application/json',
      copyToCacheDirectory: true
    });
    
    if (result.canceled) {
      return { success: false, message: 'Import cancelled' };
    }
    
    const fileContent = await FileSystem.readAsStringAsync(result.assets[0].uri);
    const importData = JSON.parse(fileContent);
    */
    
    // Validate import data structure
    if (!importData.database) {
      throw new Error('Invalid backup file format');
    }
    
    const { categories, expenses, funders, helpers, budget } = importData.database;
    
    // Show confirmation dialog
    return new Promise((resolve) => {
      Alert.alert(
        'Import Database',
        `This will replace all current data with:\n\n` +
        `• ${categories?.length || 0} Categories\n` +
        `• ${expenses?.length || 0} Expenses\n` +
        `• ${funders?.length || 0} Funders\n` +
        `• ${helpers?.length || 0} Helpers\n\n` +
        `Current data will be lost. Continue?`,
        [
          {
            text: 'Cancel',
            style: 'cancel',
            onPress: () => resolve({ success: false, message: 'Import cancelled' })
          },
          {
            text: 'Import',
            style: 'destructive',
            onPress: async () => {
              try {
                await performImport(importData);
                resolve({ success: true, message: 'Import completed successfully' });
              } catch (error) {
                resolve({ success: false, message: error.message });
              }
            }
          }
        ]
      );
    });
    
  } catch (error) {
    console.error('Import error:', error);
    Alert.alert('Import Failed', 'Could not import database. Please check the file format.');
    return { success: false, message: error.message };
  }
};

// Perform the actual import
const performImport = async (importData) => {
  try {
    const { categories, expenses, funders, helpers, budget } = importData.database;
    
    // Clear existing data (implement clear functions in sqliteService if needed)
    // For now, we'll add new data (might create duplicates)
    
    let importStats = {
      categories: 0,
      expenses: 0,
      funders: 0,
      helpers: 0
    };
    
    // Import categories
    if (categories && Array.isArray(categories)) {
      for (const category of categories) {
        try {
          await addCategory({ name: category.name });
          importStats.categories++;
        } catch (error) {
          console.warn('Failed to import category:', category.name, error);
        }
      }
    }
    
    // Import funders
    if (funders && Array.isArray(funders)) {
      for (const funder of funders) {
        try {
          await addFunder({ name: funder.name });
          importStats.funders++;
        } catch (error) {
          console.warn('Failed to import funder:', funder.name, error);
        }
      }
    }
    
    // Import helpers
    if (helpers && Array.isArray(helpers)) {
      for (const helper of helpers) {
        try {
          await addHelper({ name: helper.name });
          importStats.helpers++;
        } catch (error) {
          console.warn('Failed to import helper:', helper.name, error);
        }
      }
    }
    
    // Import expenses
    if (expenses && Array.isArray(expenses)) {
      for (const expense of expenses) {
        try {
          await addExpense({
            title: expense.title,
            amount: expense.amount,
            status: expense.status,
            categoryId: expense.categoryId,
            funderId: expense.funderId,
            assignedTo: expense.assignedTo
          });
          importStats.expenses++;
        } catch (error) {
          console.warn('Failed to import expense:', expense.title, error);
        }
      }
    }
    
    // Import budget
    if (budget) {
      try {
        await updateBudgetSummary(budget);
      } catch (error) {
        console.warn('Failed to import budget:', error);
      }
    }
    
    Alert.alert(
      'Import Complete',
      `Successfully imported:\n\n` +
      `• ${importStats.categories} Categories\n` +
      `• ${importStats.expenses} Expenses\n` +
      `• ${importStats.funders} Funders\n` +
      `• ${importStats.helpers} Helpers\n\n` +
      `Please refresh the app to see changes.`
    );
    
    return importStats;
    
  } catch (error) {
    console.error('Import execution error:', error);
    throw new Error('Failed to import data: ' + error.message);
  }
};

// Get database statistics
export const getDatabaseStats = async () => {
  try {
    const [categories, expenses, funders, helpers, budget] = await Promise.all([
      getCategories(),
      getExpenses(), 
      getFunders(),
      getHelpers(),
      getBudgetSummary()
    ]);
    
    return {
      categories: categories.length,
      expenses: expenses.length,
      funders: funders.length,
      helpers: helpers.length,
      totalBudget: budget.totalBudget || 0,
      lastUpdated: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error getting database stats:', error);
    return {
      categories: 0,
      expenses: 0,
      funders: 0,
      helpers: 0,
      totalBudget: 0,
      error: error.message
    };
  }
};