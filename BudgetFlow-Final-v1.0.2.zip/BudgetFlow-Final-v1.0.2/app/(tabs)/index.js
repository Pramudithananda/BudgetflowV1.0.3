import { useState, useEffect } from 'react';
import { StyleSheet, ScrollView, View as RNView, ActivityIndicator, RefreshControl, Alert, StatusBar } from 'react-native';
import { Text, View } from '../../components/Themed';
import { router } from 'expo-router';
import { FontAwesome5 } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import BudgetSummary from '../../components/BudgetSummary';
import Card from '../../components/Card';
import Button from '../../components/Button';
import CategoryItem from '../../components/CategoryItem';
import ExpenseItem from '../../components/ExpenseItem';
import { getCategories, getExpenses, getBudgetSummary, listenExpenses, listenCategories, getEvents, getExpensesByEvent } from '../../services/sqliteService';
import { useTheme } from '../../context/theme';
import i18n from '../../utils/i18n';


export default function HomeScreen() {
  const { colors, isDarkMode } = useTheme();
  const [, forceUpdate] = useState({});

  useEffect(() => {
    const languageListener = (newLang) => {
      console.log('Language changed in home screen:', newLang);
      forceUpdate({});
    };
    i18n.addListener(languageListener);
    return () => i18n.removeListener(languageListener);
  }, []);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [categories, setCategories] = useState([]);
  const [recentExpenses, setRecentExpenses] = useState([]);
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState('all');
  const [showEventPicker, setShowEventPicker] = useState(false);
  const [budgetSummary, setBudgetSummary] = useState({
    totalBudget: 0,
    receivedFund: 0,
  });
  const [statusTotals, setStatusTotals] = useState({
    remaining: 0,
    pending: 0,
    received: 0,
    spent: 0,
  });

  const fetchData = async () => {
    try {
      setLoading(true);
      
      console.log('=== HOME SCREEN DATA FETCH ===');
      console.log('Starting data fetch...');
      
      // Add delay to ensure database is fully initialized
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      let budgetData, expensesData, categoriesData;
      
      try {
        budgetData = await getBudgetSummary();
        console.log('Budget data loaded:', budgetData);
      } catch (error) {
        console.error('Error loading budget:', error);
        budgetData = { totalBudget: 0, receivedFund: 0 };
      }
      
      try {
        expensesData = await getExpenses();
        console.log('Expenses data loaded:', expensesData.length, 'items');
      } catch (error) {
        console.error('Error loading expenses:', error);
        expensesData = [];
      }
      
      try {
        categoriesData = await getCategories();
        console.log('Categories data loaded:', categoriesData.length, 'items');
      } catch (error) {
        console.error('Error loading categories:', error);
        categoriesData = [];
      }
      
      let eventsData = [];
      try {
        eventsData = await getEvents();
        console.log('Events data loaded:', eventsData.length, 'items');
        setEvents(eventsData);
      } catch (error) {
        console.error('Error loading events:', error);
        eventsData = [];
      }
      
      console.log('All data loaded successfully');
      
      // Calculate total budget as sum of all expenses
      const totalBudget = expensesData.reduce((sum, expense) => sum + (expense.amount || 0), 0);
      
      // Calculate received fund as sum of expenses with status "Received"
      const receivedFund = expensesData
        .filter(expense => expense.status === 'Received')
        .reduce((sum, expense) => sum + (expense.amount || 0), 0);
      
      setBudgetSummary({
        totalBudget,
        receivedFund,
      });
      
      // Calculate totals for each status
      const totals = {
        remaining: 0,
        pending: 0,
        received: 0,
        spent: 0,
      };
      
      expensesData.forEach(expense => {
        if (expense.status === 'Outstanding') {
          totals.remaining += expense.amount;
        } else if (expense.status === 'Pending') {
          totals.pending += expense.amount;
        } else if (expense.status === 'Received') {
          totals.received += expense.amount;
        } else if (expense.status === 'Spent') {
          totals.spent += expense.amount;
        }
      });
      
      setStatusTotals(totals);
      
      // Calculate totals for each category
      const categoriesWithTotals = categoriesData.map(category => {
        const categoryExpenses = expensesData.filter(expense => expense.categoryId === category.id);
        const totalAmount = categoryExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
        const expenseCount = categoryExpenses.length;
        
        return {
          ...category,
          totalAmount,
          expenseCount
        };
      });
      
      setCategories(categoriesWithTotals);
      
      // Filter expenses based on selected event
      const filteredExpenses = selectedEvent === 'all' 
        ? expensesData 
        : expensesData.filter(expense => expense.eventId === parseInt(selectedEvent));
      
      // Recalculate budget summary for filtered expenses
      const filteredTotalBudget = filteredExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
      const filteredReceivedFund = filteredExpenses
        .filter(expense => expense.status === 'Received')
        .reduce((sum, expense) => sum + (expense.amount || 0), 0);
      
      setBudgetSummary({
        totalBudget: filteredTotalBudget,
        receivedFund: filteredReceivedFund,
      });
      
      // Recalculate status totals for filtered expenses
      const filteredTotals = { remaining: 0, pending: 0, received: 0, spent: 0 };
      filteredExpenses.forEach(expense => {
        if (expense.status === 'Outstanding') filteredTotals.remaining += expense.amount;
        else if (expense.status === 'Pending') filteredTotals.pending += expense.amount;
        else if (expense.status === 'Received') filteredTotals.received += expense.amount;
        else if (expense.status === 'Spent') filteredTotals.spent += expense.amount;
      });
      setStatusTotals(filteredTotals);
      
      setRecentExpenses(filteredExpenses.slice(0, 5)); // Get only 5 most recent expenses
    } catch (error) {
      console.error('Error fetching data:', error);
      Alert.alert(
        'Startup Error', 
        `Could not load app data.\n\nError: ${error.message}\n\nThis might be a database initialization issue. Try restarting the app.`
      );
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const handleEventChange = (eventId) => {
    setSelectedEvent(eventId);
    // Trigger data refresh with new filter
    fetchData();
  };

  const generateEventReport = async (eventId, eventData) => {
    try {
      const Print = require('expo-print');
      const Sharing = require('expo-sharing');
      
      const eventExpenses = await getExpensesByEvent(parseInt(eventId));
      
      if (!eventData) {
        Alert.alert('Error', 'Event not found');
        return null;
      }
      
      // Calculate event statistics
      const totalExpenses = eventExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
      const statusCounts = { remaining: 0, pending: 0, received: 0, spent: 0 };
      const statusAmounts = { remaining: 0, pending: 0, received: 0, spent: 0 };
      
      eventExpenses.forEach(expense => {
        if (expense.status === 'Outstanding') {
          statusCounts.remaining++;
          statusAmounts.remaining += expense.amount || 0;
        } else if (expense.status === 'Pending') {
          statusCounts.pending++;
          statusAmounts.pending += expense.amount || 0;
        } else if (expense.status === 'Received') {
          statusCounts.received++;
          statusAmounts.received += expense.amount || 0;
        } else if (expense.status === 'Spent') {
          statusCounts.spent++;
          statusAmounts.spent += expense.amount || 0;
        }
      });
      
      const remainingBudget = (eventData.budget || 0) - totalExpenses;
      const budgetUsagePercent = eventData.budget > 0 ? Math.round((totalExpenses / eventData.budget) * 100) : 0;
      
      const report = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>${eventData.name} - Expense Report</title>
    <style>
        @page { size: A4; margin: 2cm; }
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #64a12d; padding-bottom: 20px; }
        .header h1 { color: #64a12d; margin: 0; font-size: 24px; }
        .header p { color: #666; margin: 10px 0 0; }
        .event-info { background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
        .section { margin-bottom: 30px; page-break-inside: avoid; }
        .section-title { font-size: 18px; font-weight: bold; color: #64a12d; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 5px; }
        .budget-overview { display: flex; justify-content: space-around; margin: 20px 0; }
        .budget-item { text-align: center; }
        .budget-value { font-size: 20px; font-weight: bold; color: #64a12d; }
        .budget-label { font-size: 14px; color: #666; }
        .status-indicator { padding: 10px; border-radius: 5px; text-align: center; margin: 15px 0; font-weight: bold; }
        .within-budget { background-color: #d4edda; color: #155724; }
        .over-budget { background-color: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #eee; }
        th { background-color: #f8f8f8; color: #64a12d; }
        .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #eee; padding-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>${eventData.name} - Expense Report</h1>
        <p>Generated on: ${new Date().toLocaleString()}</p>
        <p>Developer: Ranjith Karunarathne | Email: ranjithpalugolla@gmail.com</p>
    </div>

    <div class="event-info">
        <h2>Event Information</h2>
        <p><strong>Event Name:</strong> ${eventData.name}</p>
        <p><strong>Description:</strong> ${eventData.description || 'No description'}</p>
        <p><strong>Status:</strong> ${eventData.status}</p>
        ${eventData.location ? `<p><strong>Location:</strong> ${eventData.location}</p>` : ''}
        ${eventData.startDate ? `<p><strong>Start Date:</strong> ${eventData.startDate}</p>` : ''}
        ${eventData.endDate ? `<p><strong>End Date:</strong> ${eventData.endDate}</p>` : ''}
    </div>

    <div class="section">
        <div class="section-title">Budget Overview</div>
        <div class="budget-overview">
            <div class="budget-item">
                <div class="budget-value">Rs. ${(eventData.budget || 0).toLocaleString()}</div>
                <div class="budget-label">Event Budget</div>
            </div>
            <div class="budget-item">
                <div class="budget-value">Rs. ${totalExpenses.toLocaleString()}</div>
                <div class="budget-label">Total Expenses</div>
            </div>
            <div class="budget-item">
                <div class="budget-value">Rs. ${remainingBudget.toLocaleString()}</div>
                <div class="budget-label">Remaining</div>
            </div>
            <div class="budget-item">
                <div class="budget-value">${budgetUsagePercent}%</div>
                <div class="budget-label">Budget Used</div>
            </div>
        </div>
        <div class="status-indicator ${remainingBudget >= 0 ? 'within-budget' : 'over-budget'}">
            ${remainingBudget >= 0 ? '✅ Within Budget' : '⚠️ Over Budget'}
        </div>
    </div>

    <div class="section">
        <div class="section-title">Expense Status</div>
        <table>
            <tr><th>Status</th><th>Count</th><th>Amount</th></tr>
            <tr><td>Outstanding</td><td>${statusCounts.remaining}</td><td class="amount">Rs. ${statusAmounts.remaining.toLocaleString()}</td></tr>
            <tr><td>Pending</td><td>${statusCounts.pending}</td><td class="amount">Rs. ${statusAmounts.pending.toLocaleString()}</td></tr>
            <tr><td>Available</td><td>${statusCounts.received}</td><td class="amount">Rs. ${statusAmounts.received.toLocaleString()}</td></tr>
            <tr><td>Spent</td><td>${statusCounts.spent}</td><td class="amount">Rs. ${statusAmounts.spent.toLocaleString()}</td></tr>
        </table>
    </div>

    <div class="section">
        <div class="section-title">Event Expenses</div>
        <table>
            <tr><th>Title</th><th>Amount</th><th>Status</th><th>Category</th><th>Funder</th><th>Date</th></tr>
            ${eventExpenses.map(expense => `
                <tr>
                    <td>${expense.title}</td>
                    <td class="amount">Rs. ${expense.amount.toLocaleString()}</td>
                    <td>${expense.status}</td>
                    <td>${categoriesData.find(c => c.id === expense.categoryId)?.name || 'N/A'}</td>
                    <td>${fundersData.find(f => f.id === expense.funderId)?.name || 'N/A'}</td>
                    <td>${new Date(expense.createdAt).toLocaleDateString()}</td>
                </tr>
            `).join('')}
        </table>
    </div>

    <div class="footer">
        <p>This report was generated by BudgetFlow - Event Management System</p>
        <p>Developed by Ranjith Karunarathne (ranjithpalugolla@gmail.com)</p>
    </div>
</body>
</html>
      `;
      
      // Generate PDF
      const { uri } = await Print.printToFileAsync({
        html: report,
        width: 612,
        height: 792,
      });

      // Share PDF
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, {
          mimeType: 'application/pdf',
          dialogTitle: `${eventData.name} Report`,
        });
      } else {
        Alert.alert('Error', 'Sharing is not available on this device');
      }
    } catch (error) {
      console.error('Error generating event report:', error);
      Alert.alert('Error', 'Could not generate event report');
    }
  };

  const handleGenerateEventReport = () => {
    if (selectedEvent === 'all') {
              Alert.alert(i18n.t('selectEvent'), i18n.t('selectEventFirst'));
      return;
    }
    
    const eventData = events.find(e => e.id.toString() === selectedEvent);
    if (!eventData) {
      Alert.alert(i18n.t('error'), i18n.t('eventNotFound'));
      return;
    }
    
    generateEventReport(selectedEvent, eventData);
  };

  useEffect(() => {
    fetchData();
  const unsubscribeExpenses = listenExpenses(null, (expensesLive) => {
      const expensesData = expensesLive.map(exp => ({
        ...exp,
        createdAt: exp.createdAt?.toDate ? exp.createdAt.toDate().toISOString() : exp.createdAt,
      }));
      // Recompute budget & status totals
      const totalBudget = expensesData.reduce((sum, e) => sum + (e.amount || 0), 0);
      const receivedFund = expensesData.filter(e=> e.status==='Received').reduce((s,e)=> s + (e.amount||0),0);
      setBudgetSummary(prev => ({ ...prev, totalBudget, receivedFund }));
      const totals = { remaining:0,pending:0,received:0,spent:0 };
      expensesData.forEach(e=>{
        if(e.status==='Outstanding') totals.remaining += e.amount||0;
        else if(e.status==='Pending') totals.pending += e.amount||0;
        else if(e.status==='Received') totals.received += e.amount||0;
        else if(e.status==='Spent') totals.spent += e.amount||0;
      });
      setStatusTotals(totals);
      // Update categories amounts (requires categories state)
      setCategories(prevCats => prevCats.map(cat => {
        const catExpenses = expensesData.filter(e=> e.categoryId===cat.id);
        const totalAmount = catExpenses.reduce((s,e)=> s + (e.amount||0),0);
        return { ...cat, totalAmount, expenseCount: catExpenses.length };
      }));
      setRecentExpenses(expensesData.slice(0,5));
    });
    // Listen for category additions/updates
    const unsubscribeCategories = listenCategories((catsLive) => {
      setCategories(prev => {
        // Merge updated categories while preserving computed totals (will be recomputed below anyway)
        return catsLive.map(c => prev.find(p=>p.id===c.id) ? { ...c, ...prev.find(p=>p.id===c.id) } : { ...c, totalAmount:0, expenseCount:0 });
      });
    });
    return () => {
      unsubscribeExpenses && unsubscribeExpenses();
      unsubscribeCategories && unsubscribeCategories();
    };
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <>
      <StatusBar
        barStyle="light-content"
        backgroundColor={colors.primary}
        translucent={false}
      />
      <ScrollView 
        style={[styles.container, { backgroundColor: colors.background }]}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Event Filter Card */}
        <Card style={styles.sectionCard}>
          <RNView style={styles.eventFilterHeader}>
            <Text style={styles.sectionTitle}>{i18n.t('eventFilter')}</Text>
            <FontAwesome5 name="filter" size={16} color={colors.primary} />
          </RNView>
          
          <RNView style={styles.eventPickerContainer}>
            <Text style={styles.filterLabel}>{i18n.t('selectEvent')}</Text>
            <RNView style={[styles.pickerWrapper, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Picker
                selectedValue={selectedEvent}
                onValueChange={handleEventChange}
                style={[styles.eventPicker, { color: colors.text }]}
              >
                <Picker.Item label={i18n.t('allEvents')} value="all" />
                {events.map(event => (
                  <Picker.Item 
                    key={event.id} 
                    label={`${event.name} (Rs. ${(event.budget || 0).toLocaleString()})`} 
                    value={event.id.toString()} 
                  />
                ))}
              </Picker>
            </RNView>
          </RNView>
          
          {selectedEvent !== 'all' && (
            <RNView style={styles.selectedEventInfo}>
              {(() => {
                const eventData = events.find(e => e.id.toString() === selectedEvent);
                return eventData ? (
                  <RNView>
                    <Text style={styles.selectedEventTitle}>📅 {eventData.name}</Text>
                    <RNView style={styles.eventBudgetRow}>
                      <Text style={styles.eventBudgetLabel}>Event Budget:</Text>
                      <Text style={[styles.eventBudgetValue, { color: colors.primary }]}>
                        Rs. {(eventData.budget || 0).toLocaleString()}
                      </Text>
                    </RNView>
                    <RNView style={styles.eventBudgetRow}>
                      <Text style={styles.eventBudgetLabel}>Current Expenses:</Text>
                      <Text style={[styles.eventBudgetValue, { color: colors.primary }]}>
                        Rs. {budgetSummary.totalBudget.toLocaleString()}
                      </Text>
                    </RNView>
                    <RNView style={styles.eventBudgetRow}>
                      <Text style={styles.eventBudgetLabel}>Remaining:</Text>
                      <Text style={[styles.eventBudgetValue, { 
                        color: (eventData.budget || 0) >= budgetSummary.totalBudget ? '#4CAF50' : '#f44336' 
                      }]}>
                        Rs. {((eventData.budget || 0) - budgetSummary.totalBudget).toLocaleString()}
                      </Text>
                    </RNView>
                    <RNView style={[styles.budgetStatus, {
                      backgroundColor: (eventData.budget || 0) >= budgetSummary.totalBudget ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)'
                    }]}>
                      <Text style={[styles.budgetStatusText, {
                        color: (eventData.budget || 0) >= budgetSummary.totalBudget ? '#4CAF50' : '#f44336'
                      }]}>
                        {(eventData.budget || 0) >= budgetSummary.totalBudget ? '✅ Within Budget' : '⚠️ Over Budget'}
                        {' '}({eventData.budget > 0 ? Math.round((budgetSummary.totalBudget / eventData.budget) * 100) : 0}% used)
                      </Text>
                    </RNView>
                    
                    {/* Event Report Button */}
                    <RNView style={styles.eventReportButtonContainer}>
                      <Button
                        title={i18n.t('generateEventReport')}
                        onPress={() => handleGenerateEventReport()}
                        variant="outline"
                        style={styles.eventReportButton}
                        icon={<FontAwesome5 name="file-pdf" size={16} color={colors.primary} style={styles.buttonIcon} />}
                      />
                    </RNView>
                  </RNView>
                ) : null;
              })()}
            </RNView>
          )}
        </Card>

        <BudgetSummary
          totalBudget={budgetSummary.totalBudget}
          receivedFund={budgetSummary.receivedFund}
          spent={statusTotals.spent}
          eventName={selectedEvent !== 'all' ? events.find(e => e.id.toString() === selectedEvent)?.name : null}
          eventBudget={selectedEvent !== 'all' ? events.find(e => e.id.toString() === selectedEvent)?.budget : null}
        />
        
        <Card style={styles.sectionCard}>
          <RNView style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Expense Status</Text>
          </RNView>
          <RNView style={styles.statusCardsContainer}>
            <RNView style={[styles.statusCard, { backgroundColor: isDarkMode ? 'rgba(255, 39, 39, 0.73)' : '#FFCCCC' }]}>
              <Text style={styles.statusAmount}>Rs. {(statusTotals.remaining || 0).toLocaleString()}</Text>
              <Text style={styles.statusLabel}>Outstanding</Text>
            </RNView>
            <RNView style={[styles.statusCard, { backgroundColor: isDarkMode ? 'rgba(255, 148, 33, 0.7)' : '#ffe0b2ff' }]}>
              <Text style={styles.statusAmount}>Rs. {(statusTotals.pending || 0).toLocaleString()}</Text>
              <Text style={styles.statusLabel}>Pending</Text>
            </RNView>
            <RNView style={[styles.statusCard, { backgroundColor: isDarkMode ? 'rgba(51, 125, 254, 0.57)' : '#c4d9ffff' }]}>
              <Text style={styles.statusAmount}>Rs. {(statusTotals.received || 0).toLocaleString()}</Text>
              <Text style={styles.statusLabel}>Available</Text>
            </RNView>
            <RNView style={[styles.statusCard, { backgroundColor: isDarkMode ? 'rgba(83, 255, 49, 0.5)' : '#3ee14977' }]}>
              <Text style={styles.statusAmount}>Rs. {(statusTotals.spent || 0).toLocaleString()}</Text>
              <Text style={styles.statusLabel}>Spent</Text>
            </RNView>
          </RNView>
        </Card>
        
        <Card style={styles.sectionCard}>
          <RNView style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Categories</Text>
            <Button 
              title="Add Category" 
              onPress={() => router.push('/new-category')}
              variant="outline"
              style={styles.addButton}
            />
          </RNView>
          
          {categories.length === 0 ? (
            <RNView style={styles.emptyState}>
              <FontAwesome5 name="list" size={24} color={colors.text} />
              <Text style={styles.emptyText}>No categories yet</Text>
              <Text style={styles.emptySubtext}>Add categories to organize your expenses</Text>
            </RNView>
          ) : (
            categories.slice(0, 3).map((category) => (
              <CategoryItem
                key={category.id}
                name={category.name}
                totalExpenses={category.expenseCount || 0}
                totalAmount={category.totalAmount || 0}
                onPress={() => router.push(`/category/${category.id}`)}
              />
            ))
          )}
          
          {categories.length > 3 && (
            <Button
              title="View All Categories"
              onPress={() => router.push('/category')}
              variant="outline"
              style={styles.viewAllButton}
            />
          )}
        </Card>
        
        <Card style={styles.sectionCard}>
          <RNView style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>
              {selectedEvent === 'all' 
                ? 'Recent Expenses (All Events)' 
                : `${events.find(e => e.id.toString() === selectedEvent)?.name || 'Event'} Expenses`
              }
            </Text>
          </RNView>
          
          {recentExpenses.length === 0 ? (
            <RNView style={styles.emptyState}>
              <FontAwesome5 name="receipt" size={24} color={colors.text} />
              <Text style={styles.emptyText}>No expenses yet</Text>
              <Text style={styles.emptySubtext}>Add your first expense to get started</Text>
            </RNView>
          ) : (
            recentExpenses.map((expense) => (
              <ExpenseItem
                key={expense.id}
                title={expense.title}
                amount={expense.amount}
                status={expense.status}
                assignedTo={expense.assignedTo}
                onPress={() => router.push(`/expense/${expense.id}`)}
              />
            ))
          )}
          
          {/* Expense Card Footer with Add Button */}
          <RNView style={styles.expenseFooter}>
            <Button 
                              title={i18n.t('addExpense')} 
              onPress={() => router.push(selectedEvent === 'all' ? '/new-expense' : `/new-expense?eventId=${selectedEvent}`)}
              style={styles.addExpenseButton}
              icon={<FontAwesome5 name="plus" size={16} color="#fff" style={styles.buttonIcon} />}
            />
            {recentExpenses.length > 0 && (
              <Button
                title={i18n.t('viewAll')}
                onPress={() => router.push('/all-expenses')}
                variant="outline"
                style={styles.viewAllButtonSmall}
              />
            )}
          </RNView>
        </Card>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionCard: {
    marginTop: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  statusCardsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statusCard: {
    width: '48%',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  statusAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statusLabel: {
    fontSize: 14,
  },
  addButton: {
    width: 150,
  },
  viewAllButton: {
    marginTop: 16,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
  },
  emptySubtext: {
    fontSize: 14,
    marginTop: 4,
  },
  eventFilterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  eventPickerContainer: {
    marginBottom: 16,
  },
  filterLabel: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  pickerWrapper: {
    borderWidth: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  eventPicker: {
    height: 50,
  },
  selectedEventInfo: {
    marginTop: 16,
    padding: 16,
    backgroundColor: 'rgba(100, 161, 45, 0.05)',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(100, 161, 45, 0.2)',
  },
  selectedEventTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
  },
  eventBudgetRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  eventBudgetLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  eventBudgetValue: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  budgetStatus: {
    marginTop: 12,
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  budgetStatusText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  expenseFooter: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.1)',
  },
  addExpenseButton: {
    flex: 1,
    marginHorizontal: 8,
    maxWidth: 200,
  },
  viewAllButtonSmall: {
    flex: 1,
    marginHorizontal: 8,
    maxWidth: 120,
  },
  buttonIcon: {
    marginRight: 8,
  },
}); 