import React, { useState, useEffect } from 'react';
import { StyleSheet, ScrollView, View as RNView, Alert } from 'react-native';
import { Text, View } from '../../components/Themed';
import { FontAwesome5, MaterialIcons } from '@expo/vector-icons';
import { Picker } from '@react-native-picker/picker';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { useTheme } from '../../context/theme';
import i18n from '../../utils/i18n';

export default function SettingsScreen() {
  const { colors, isDarkMode } = useTheme();
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [, forceUpdate] = useState({});

  useEffect(() => {
    setCurrentLanguage(i18n.getCurrentLanguage());
    
    const languageListener = (newLang) => {
      setCurrentLanguage(newLang);
      forceUpdate({});
    };
    
    i18n.addListener(languageListener);
    return () => i18n.removeListener(languageListener);
  }, []);

  const handleLanguageChange = async (languageCode) => {
    if (languageCode !== currentLanguage) {
      const success = await i18n.changeLanguage(languageCode);
      if (success) {
        Alert.alert(i18n.t('success'), i18n.t('languageChanged'));
      }
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Language Settings */}
        <Card style={styles.card}>
          <RNView style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              🌐 {i18n.t('language')}
            </Text>
            <FontAwesome5 name="globe" size={20} color={colors.primary} />
          </RNView>
          
          <RNView style={styles.languageContainer}>
            <Text style={[styles.languageLabel, { color: colors.text }]}>
              {i18n.t('selectLanguage')}:
            </Text>
            <RNView style={[styles.pickerWrapper, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Picker
                selectedValue={currentLanguage}
                onValueChange={handleLanguageChange}
                style={[styles.languagePicker, { color: colors.text }]}
              >
                <Picker.Item label="🇺🇸 English" value="en" />
                <Picker.Item label="🇱🇰 සිංහල" value="si" />
              </Picker>
            </RNView>
          </RNView>
        </Card>

        {/* App Information */}
        <Card style={styles.card}>
          <RNView style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              ℹ️ {i18n.t('about')}
            </Text>
            <FontAwesome5 name="info-circle" size={20} color={colors.primary} />
          </RNView>
          
          <RNView style={styles.infoContainer}>
            <RNView style={styles.infoRow}>
              <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>
                {i18n.t('appName')}:
              </Text>
              <Text style={[styles.infoValue, { color: colors.text }]}>
                BudgetFlow
              </Text>
            </RNView>
            
            <RNView style={styles.infoRow}>
              <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>
                {i18n.t('version')}:
              </Text>
              <Text style={[styles.infoValue, { color: colors.text }]}>
                1.0.2
              </Text>
            </RNView>
            
            <RNView style={styles.infoRow}>
              <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>
                {i18n.t('developer')}:
              </Text>
              <Text style={[styles.infoValue, { color: colors.text }]}>
                Dilsan Pathum
              </Text>
            </RNView>
            
            <RNView style={styles.infoRow}>
              <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>
                Email:
              </Text>
              <Text style={[styles.infoValue, { color: colors.primary }]}>
                pathumpanagoda@gmail.com
              </Text>
            </RNView>
          </RNView>
        </Card>

        {/* Features */}
        <Card style={styles.card}>
          <RNView style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              🚀 {i18n.t('features')}
            </Text>
            <FontAwesome5 name="star" size={20} color={colors.primary} />
          </RNView>
          
          <RNView style={styles.featuresContainer}>
            <RNView style={styles.featureItem}>
              <FontAwesome5 name="chart-pie" size={16} color={colors.primary} />
              <Text style={[styles.featureText, { color: colors.text }]}>
                {i18n.t('budgetManagement')}
              </Text>
            </RNView>
            
            <RNView style={styles.featureItem}>
              <FontAwesome5 name="calendar-alt" size={16} color={colors.primary} />
              <Text style={[styles.featureText, { color: colors.text }]}>
                {i18n.t('eventManagement')}
              </Text>
            </RNView>
            
            <RNView style={styles.featureItem}>
              <FontAwesome5 name="file-pdf" size={16} color={colors.primary} />
              <Text style={[styles.featureText, { color: colors.text }]}>
                {i18n.t('pdfReports')}
              </Text>
            </RNView>
            
            <RNView style={styles.featureItem}>
              <FontAwesome5 name="database" size={16} color={colors.primary} />
              <Text style={[styles.featureText, { color: colors.text }]}>
                {i18n.t('sqliteDatabase')}
              </Text>
            </RNView>
            
            <RNView style={styles.featureItem}>
              <FontAwesome5 name="mobile-alt" size={16} color={colors.primary} />
              <Text style={[styles.featureText, { color: colors.text }]}>
                {i18n.t('offlineSupport')}
              </Text>
            </RNView>
            
            <RNView style={styles.featureItem}>
              <FontAwesome5 name="share" size={16} color={colors.primary} />
              <Text style={[styles.featureText, { color: colors.text }]}>
                {i18n.t('dataExportImport')}
              </Text>
            </RNView>
          </RNView>
        </Card>

        {/* Theme */}
        <Card style={styles.card}>
          <RNView style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              🎨 Theme
            </Text>
            <MaterialIcons name="palette" size={20} color={colors.primary} />
          </RNView>
          
          <RNView style={styles.themeContainer}>
            <Text style={[styles.themeText, { color: colors.text }]}>
              Current Theme: {isDarkMode ? 'Dark Mode' : 'Light Mode'}
            </Text>
            <RNView style={styles.themeNote}>
              <Text style={[styles.noteText, { color: colors.textSecondary }]}>
                Theme switches automatically based on system settings
              </Text>
            </RNView>
          </RNView>
        </Card>

        {/* Contact */}
        <Card style={styles.card}>
          <RNView style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              📞 Contact
            </Text>
            <FontAwesome5 name="envelope" size={20} color={colors.primary} />
          </RNView>
          
          <RNView style={styles.contactContainer}>
            <Text style={[styles.contactText, { color: colors.text }]}>
              For support or feedback, contact:
            </Text>
            <Text style={[styles.contactEmail, { color: colors.primary }]}>
              ranjithpalugolla@gmail.com
            </Text>
          </RNView>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  card: {
    marginBottom: 16,
    padding: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  infoContainer: {
    marginTop: 8,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.1)',
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  featuresContainer: {
    marginTop: 8,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  featureText: {
    fontSize: 14,
    marginLeft: 12,
  },
  themeContainer: {
    marginTop: 8,
  },
  themeText: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  themeNote: {
    padding: 12,
    backgroundColor: 'rgba(100, 161, 45, 0.1)',
    borderRadius: 8,
  },
  noteText: {
    fontSize: 12,
    fontStyle: 'italic',
  },
  contactContainer: {
    marginTop: 8,
    alignItems: 'center',
  },
  contactText: {
    fontSize: 14,
    marginBottom: 8,
  },
  contactEmail: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  languageContainer: {
    marginTop: 8,
  },
  languageLabel: {
    fontSize: 16,
    marginBottom: 12,
    fontWeight: '600',
  },
  pickerWrapper: {
    borderWidth: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  languagePicker: {
    height: 50,
  },
});