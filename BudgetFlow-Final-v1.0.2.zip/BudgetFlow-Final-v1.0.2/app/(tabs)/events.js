import { useState, useEffect } from 'react';
import { StyleSheet, ScrollView, View as RNView, ActivityIndicator, RefreshControl, Alert } from 'react-native';
import { Text, View } from '../../components/Themed';
import { router } from 'expo-router';
import { FontAwesome5 } from '@expo/vector-icons';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { getEvents, listenEvents, deleteEvent, getExpensesByEvent } from '../../services/sqliteService';
import { useTheme } from '../../context/theme';

export default function EventsScreen() {
  const { colors, isDarkMode } = useTheme();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [events, setEvents] = useState([]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      const eventsData = await getEvents();
      
      // Calculate expense totals for each event
      const eventsWithTotals = await Promise.all(
        eventsData.map(async (event) => {
          try {
            const eventExpenses = await getExpensesByEvent(event.id);
            const totalExpenses = eventExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
            const expenseCount = eventExpenses.length;
            
            return {
              ...event,
              totalExpenses,
              expenseCount
            };
          } catch (error) {
            console.error('Error calculating event totals:', error);
            return {
              ...event,
              totalExpenses: 0,
              expenseCount: 0
            };
          }
        })
      );
      
      setEvents(eventsWithTotals);
    } catch (error) {
      console.error('Error fetching events data:', error);
      Alert.alert('Error', 'Could not load events data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const handleDeleteEvent = async (eventId, eventName) => {
    Alert.alert(
      'Delete Event',
      `Are you sure you want to delete "${eventName}"? This will also remove the event association from all related expenses.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteEvent(eventId);
              Alert.alert('Success', 'Event deleted successfully');
              fetchData(); // Refresh data
            } catch (error) {
              console.error('Error deleting event:', error);
              Alert.alert('Error', 'Could not delete event. Please try again.');
            }
          }
        }
      ]
    );
  };

  useEffect(() => {
    fetchData();
    
    // Listen for real-time updates
    const unsubscribe = listenEvents((eventsLive) => {
      // Recalculate totals for live events
      const updateEventTotals = async () => {
        const eventsWithTotals = await Promise.all(
          eventsLive.map(async (event) => {
            try {
              const eventExpenses = await getExpensesByEvent(event.id);
              const totalExpenses = eventExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);
              const expenseCount = eventExpenses.length;
              
              return {
                ...event,
                totalExpenses,
                expenseCount
              };
            } catch (error) {
              return {
                ...event,
                totalExpenses: 0,
                expenseCount: 0
              };
            }
          })
        );
        setEvents(eventsWithTotals);
      };
      
      updateEventTotals();
    });
    
    return () => {
      unsubscribe && unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <Card style={styles.headerCard}>
        <RNView style={styles.headerContent}>
          <RNView style={styles.headerText}>
            <Text style={styles.headerTitle}>Event Management</Text>
            <Text style={styles.headerSubtitle}>Manage multiple events and their expenses</Text>
          </RNView>
          <Button 
            title="Add Event" 
            onPress={() => router.push('/new-event')}
            variant="outline"
            style={styles.addButton}
          />
        </RNView>
      </Card>
      
      {events.length === 0 ? (
        <Card style={styles.emptyCard}>
          <RNView style={styles.emptyState}>
            <FontAwesome5 name="calendar-plus" size={48} color={colors.text} />
            <Text style={styles.emptyTitle}>No Events Yet</Text>
            <Text style={styles.emptySubtitle}>Create your first event to start tracking expenses</Text>
            <Button 
              title="Create Event" 
              onPress={() => router.push('/new-event')}
              style={styles.createButton}
            />
          </RNView>
        </Card>
      ) : (
        events.map((event) => (
          <Card key={event.id} style={styles.eventCard}>
            <RNView style={styles.eventHeader}>
              <RNView style={styles.eventInfo}>
                <Text style={styles.eventName}>{event.name}</Text>
                <Text style={styles.eventDescription}>{event.description || 'No description'}</Text>
                <RNView style={styles.eventMeta}>
                  <RNView style={[styles.statusBadge, { 
                    backgroundColor: event.status === 'Active' ? '#4CAF50' : 
                                   event.status === 'Planning' ? '#FF9800' : 
                                   event.status === 'Completed' ? '#2196F3' : '#9E9E9E' 
                  }]}>
                    <Text style={styles.statusText}>{event.status}</Text>
                  </RNView>
                  {event.location && (
                    <Text style={styles.locationText}>📍 {event.location}</Text>
                  )}
                </RNView>
              </RNView>
              <RNView style={styles.eventActions}>
                <Button
                  title="View"
                  onPress={() => router.push(`/event/${event.id}`)}
                  variant="outline"
                  style={styles.actionButton}
                />
              </RNView>
            </RNView>
            
            <RNView style={styles.eventStats}>
              <RNView style={styles.statItem}>
                <Text style={styles.statValue}>Rs. {event.totalExpenses?.toLocaleString() || '0'}</Text>
                <Text style={styles.statLabel}>Total Expenses</Text>
              </RNView>
              <RNView style={styles.statItem}>
                <Text style={styles.statValue}>Rs. {(event.budget || 0).toLocaleString()}</Text>
                <Text style={styles.statLabel}>Budget</Text>
              </RNView>
              <RNView style={styles.statItem}>
                <Text style={styles.statValue}>{event.expenseCount || 0}</Text>
                <Text style={styles.statLabel}>Expenses</Text>
              </RNView>
            </RNView>
            
            <RNView style={styles.eventFooter}>
              <Button
                title="Add Expense"
                onPress={() => router.push(`/new-expense?eventId=${event.id}`)}
                variant="outline"
                style={styles.footerButton}
                icon={<FontAwesome5 name="plus" size={14} color={colors.primary} />}
              />
              <Button
                title="Edit"
                onPress={() => router.push(`/edit-event/${event.id}`)}
                variant="outline"
                style={styles.footerButton}
                icon={<FontAwesome5 name="edit" size={14} color={colors.primary} />}
              />
              <Button
                title="Delete"
                onPress={() => handleDeleteEvent(event.id, event.name)}
                variant="outline"
                style={[styles.footerButton, { borderColor: '#f44336' }]}
                icon={<FontAwesome5 name="trash" size={14} color="#f44336" />}
              />
            </RNView>
          </Card>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerCard: {
    marginTop: 16,
    marginHorizontal: 16,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    opacity: 0.7,
  },
  addButton: {
    minWidth: 100,
  },
  emptyCard: {
    marginTop: 32,
    marginHorizontal: 16,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    opacity: 0.7,
    textAlign: 'center',
    marginBottom: 24,
  },
  createButton: {
    minWidth: 150,
  },
  eventCard: {
    marginTop: 16,
    marginHorizontal: 16,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  eventInfo: {
    flex: 1,
    marginRight: 12,
  },
  eventName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  eventDescription: {
    fontSize: 14,
    opacity: 0.7,
    marginBottom: 8,
  },
  eventMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 4,
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  locationText: {
    fontSize: 12,
    opacity: 0.7,
  },
  eventActions: {
    alignItems: 'flex-end',
  },
  actionButton: {
    minWidth: 80,
  },
  eventStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'rgba(0,0,0,0.1)',
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    opacity: 0.7,
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  footerButton: {
    flex: 1,
    marginHorizontal: 4,
  },
});