import { useState, useEffect } from 'react';
import { StyleSheet, ScrollView, View as RNView, ActivityIndicator, RefreshControl, Alert } from 'react-native';
import { Text, View } from '../../../components/Themed';
import { router, useLocalSearchParams, Stack, useNavigation } from 'expo-router';
import { FontAwesome5 } from '@expo/vector-icons';
import Card from '../../../components/Card';
import Button from '../../../components/Button';
import ExpenseItem from '../../../components/ExpenseItem';
import { getEvent, getExpensesByEvent, deleteEvent } from '../../../services/sqliteService';
import { useTheme } from '../../../context/theme';

export default function EventDetailScreen() {
  const { colors, isDarkMode } = useTheme();
  const { id } = useLocalSearchParams();
  const navigation = useNavigation();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [event, setEvent] = useState(null);
  const [expenses, setExpenses] = useState([]);
  
  // Debug logging
  console.log('EventDetailScreen - Received ID:', id, 'Type:', typeof id);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      const numericId = parseInt(id);
      console.log('=== EVENT DETAIL DEBUG ===');
      console.log('URL ID:', id, 'Parsed ID:', numericId);
      
      // First check if events table exists and has data
      try {
        const allEvents = await getEvents();
        console.log('All available events:', allEvents.map(e => ({id: e.id, name: e.name})));
      } catch (error) {
        console.error('Error getting all events:', error);
      }
      
      let eventData = null;
      let expensesData = [];
      
      try {
        eventData = await getEvent(numericId);
        console.log('Retrieved event data:', eventData);
      } catch (error) {
        console.error('Error getting single event:', error);
      }
      
      if (!eventData) {
        // Try alternative ID formats
        try {
          eventData = await getEvent(id); // Try string ID
          console.log('Found event with string ID:', eventData);
        } catch (error) {
          console.error('Error with string ID:', error);
        }
      }
      
      if (!eventData) {
        console.error('Event not found with any ID format! ID:', numericId);
        Alert.alert(
          'Debug Info', 
          `Event ID: ${id} (${typeof id})\nParsed: ${numericId}\nPlease check console logs for details.`
        );
        router.back();
        return;
      }
      
      try {
        expensesData = await getExpensesByEvent(numericId);
        console.log('Retrieved expenses data:', expensesData.length, 'items');
      } catch (error) {
        console.error('Error getting expenses:', error);
        expensesData = []; // Default to empty array
      }
      
      // Calculate total amount from expenses
      const totalAmount = expensesData.reduce((sum, expense) => sum + (expense.amount || 0), 0);
      
      const eventWithStats = {
        ...eventData,
        totalAmount,
        expenseCount: expensesData.length
      };
      
      setEvent(eventWithStats);
      setExpenses(expensesData);
      
      // Update navigation title
      navigation.setOptions({
        title: eventData.name || 'Event Details',
        headerShown: true
      });
      
      console.log('=== EVENT DEBUG COMPLETE ===');
    } catch (error) {
      console.error('Error fetching event data:', error);
      Alert.alert(
        'Debug Error', 
        `Failed to load event data.\nID: ${id}\nError: ${error.message}`
      );
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const handleDeleteEvent = () => {
    Alert.alert(
      'Delete Event',
      `Are you sure you want to delete "${event?.name}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteEvent(parseInt(id));
              Alert.alert('Success', 'Event deleted successfully');
              router.back();
            } catch (error) {
              console.error('Error deleting event:', error);
              Alert.alert('Error', 'Could not delete event. Please try again.');
            }
          }
        }
      ]
    );
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!event) {
    return (
      <View style={styles.errorContainer}>
        <FontAwesome5 name="exclamation-triangle" size={48} color={colors.text} />
        <Text style={styles.errorText}>Event not found</Text>
        <Button title="Go Back" onPress={() => router.back()} />
      </View>
    );
  }

  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      {/* Event Header */}
      <Card style={styles.headerCard}>
        <RNView style={styles.eventHeader}>
          <RNView style={styles.eventInfo}>
            <Text style={styles.eventName}>{event.name}</Text>
            <Text style={styles.eventDescription}>{event.description || 'No description'}</Text>
            
            <RNView style={styles.eventMeta}>
              <RNView style={[styles.statusBadge, { 
                backgroundColor: event.status === 'Active' ? '#4CAF50' : 
                               event.status === 'Planning' ? '#FF9800' : 
                               event.status === 'Completed' ? '#2196F3' : '#9E9E9E' 
              }]}>
                <Text style={styles.statusText}>{event.status}</Text>
              </RNView>
              
              {event.location && (
                <Text style={styles.locationText}>📍 {event.location}</Text>
              )}
            </RNView>
            
            {(event.startDate || event.endDate) && (
              <RNView style={styles.dateInfo}>
                {event.startDate && (
                  <Text style={styles.dateText}>Start: {event.startDate}</Text>
                )}
                {event.endDate && (
                  <Text style={styles.dateText}>End: {event.endDate}</Text>
                )}
              </RNView>
            )}
          </RNView>
          
          <RNView style={styles.actionButtons}>
            <Button
              title="Edit"
              onPress={() => router.push(`/edit-event/${id}`)}
              variant="outline"
              style={styles.actionButton}
              icon={<FontAwesome5 name="edit" size={14} color={colors.primary} />}
            />
            <Button
              title="Delete"
              onPress={handleDeleteEvent}
              variant="outline"
              style={[styles.actionButton, { borderColor: '#f44336' }]}
              icon={<FontAwesome5 name="trash" size={14} color="#f44336" />}
            />
          </RNView>
        </RNView>
      </Card>

      {/* Event Statistics */}
      <Card style={styles.statsCard}>
        <Text style={styles.sectionTitle}>Event Statistics</Text>
        <RNView style={styles.statsContainer}>
          <RNView style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.primary }]}>Rs. {(event.budget || 0).toLocaleString()}</Text>
            <Text style={styles.statLabel}>Budget</Text>
          </RNView>
          <RNView style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.primary }]}>Rs. {(event.totalAmount || 0).toLocaleString()}</Text>
            <Text style={styles.statLabel}>Total Expenses</Text>
          </RNView>
          <RNView style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.primary }]}>{event.expenseCount || 0}</Text>
            <Text style={styles.statLabel}>Expenses</Text>
          </RNView>
          <RNView style={styles.statItem}>
            <Text style={[styles.statValue, { 
              color: (event.budget || 0) >= (event.totalAmount || 0) ? '#4CAF50' : '#f44336' 
            }]}>
              Rs. {((event.budget || 0) - (event.totalAmount || 0)).toLocaleString()}
            </Text>
            <Text style={styles.statLabel}>Remaining</Text>
          </RNView>
        </RNView>
      </Card>

      {/* Event Expenses */}
      <Card style={styles.expensesCard}>
        <RNView style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Event Expenses</Text>
          <Button 
            title="Add Expense" 
            onPress={() => router.push(`/new-expense?eventId=${id}`)}
            variant="outline"
            style={styles.addButton}
            icon={<FontAwesome5 name="plus" size={14} color={colors.primary} />}
          />
        </RNView>
        
        {expenses.length === 0 ? (
          <RNView style={styles.emptyState}>
            <FontAwesome5 name="receipt" size={32} color={colors.text} />
            <Text style={styles.emptyText}>No expenses yet</Text>
            <Text style={styles.emptySubtext}>Add expenses to track this event's costs</Text>
            <Button 
              title="Add First Expense" 
              onPress={() => router.push(`/new-expense?eventId=${id}`)}
              style={styles.firstExpenseButton}
            />
          </RNView>
        ) : (
          expenses.map((expense) => (
            <ExpenseItem
              key={expense.id}
              title={expense.title}
              amount={expense.amount}
              status={expense.status}
              assignedTo={expense.assignedTo}
              onPress={() => router.push(`/expense/${expense.id}`)}
            />
          ))
        )}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 18,
    marginVertical: 16,
  },
  headerCard: {
    marginTop: 16,
    marginHorizontal: 16,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  eventInfo: {
    flex: 1,
    marginRight: 16,
  },
  eventName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  eventDescription: {
    fontSize: 16,
    opacity: 0.7,
    marginBottom: 12,
  },
  eventMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    marginBottom: 8,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 12,
    marginBottom: 4,
  },
  statusText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  locationText: {
    fontSize: 14,
    opacity: 0.7,
  },
  dateInfo: {
    marginTop: 8,
  },
  dateText: {
    fontSize: 14,
    opacity: 0.7,
    marginBottom: 2,
  },
  actionButtons: {
    alignItems: 'flex-end',
  },
  actionButton: {
    marginBottom: 8,
    minWidth: 80,
  },
  statsCard: {
    marginTop: 16,
    marginHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    opacity: 0.7,
  },
  expensesCard: {
    marginTop: 16,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  addButton: {
    minWidth: 120,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 14,
    opacity: 0.7,
    marginBottom: 24,
  },
  firstExpenseButton: {
    minWidth: 150,
  },
});