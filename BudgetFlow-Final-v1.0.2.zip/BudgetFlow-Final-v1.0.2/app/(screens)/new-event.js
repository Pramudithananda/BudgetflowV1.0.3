import { useState } from 'react';
import { StyleSheet, ScrollView, View as RNView, TextInput, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { Text, View } from '../../components/Themed';
import { router } from 'expo-router';
import { FontAwesome5 } from '@expo/vector-icons';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { Picker } from '@react-native-picker/picker';
import { addEvent } from '../../services/sqliteService';
import { useTheme } from '../../context/theme';

export default function NewEventScreen() {
  const { colors } = useTheme();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [budget, setBudget] = useState('');
  const [status, setStatus] = useState('Planning');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Please enter an event name');
      return;
    }

    const numBudget = parseFloat(budget) || 0;
    if (budget && numBudget < 0) {
      Alert.alert('Error', 'Budget must be a positive number');
      return;
    }

    try {
      setIsSubmitting(true);

      await addEvent({
        name: name.trim(),
        description: description.trim(),
        budget: numBudget,
        status,
        location: location.trim(),
        startDate: startDate || null,
        endDate: endDate || null,
      });

      Alert.alert('Success', 'Event created successfully');
      router.back();
    } catch (error) {
      console.error('Error adding event:', error);
      Alert.alert('Error', 'Could not create event. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      style={{ flex: 1 }} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
        <Card style={styles.card}>
          <Text style={styles.title}>Create New Event</Text>
          
          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Event Name *</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={name}
              onChangeText={setName}
              placeholder="Enter event name"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={description}
              onChangeText={setDescription}
              placeholder="Enter event description"
              placeholderTextColor={colors.text + '80'}
              multiline
              numberOfLines={3}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Budget (Rs.)</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={budget}
              onChangeText={setBudget}
              placeholder="Enter budget amount"
              placeholderTextColor={colors.text + '80'}
              keyboardType="numeric"
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Status</Text>
            <RNView style={[styles.pickerContainer, { 
              borderColor: colors.border, 
              backgroundColor: colors.card 
            }]}>
              <Picker
                selectedValue={status}
                onValueChange={setStatus}
                style={[styles.picker, { color: colors.text }]}
              >
                <Picker.Item label="Planning" value="Planning" />
                <Picker.Item label="Active" value="Active" />
                <Picker.Item label="Completed" value="Completed" />
                <Picker.Item label="Cancelled" value="Cancelled" />
              </Picker>
            </RNView>
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Location</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={location}
              onChangeText={setLocation}
              placeholder="Enter event location"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Start Date (YYYY-MM-DD)</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={startDate}
              onChangeText={setStartDate}
              placeholder="2024-12-25"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>End Date (YYYY-MM-DD)</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={endDate}
              onChangeText={setEndDate}
              placeholder="2024-12-26"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.buttonContainer}>
            <Button
              title="Cancel"
              onPress={() => router.back()}
              variant="outline"
              style={styles.button}
            />
            <Button
              title={isSubmitting ? "Creating..." : "Create Event"}
              onPress={handleSubmit}
              disabled={isSubmitting}
              style={styles.button}
            />
          </RNView>
        </Card>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    margin: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  pickerContainer: {
    borderWidth: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  picker: {
    height: 50,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  button: {
    flex: 1,
    marginHorizontal: 8,
  },
});