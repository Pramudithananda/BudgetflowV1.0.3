import { useState, useEffect } from 'react';
import { StyleSheet, ScrollView, View as RNView, TextInput, Alert, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { Text, View } from '../../../components/Themed';
import { router, useLocalSearchParams } from 'expo-router';
import { FontAwesome5 } from '@expo/vector-icons';
import Card from '../../../components/Card';
import Button from '../../../components/Button';
import { Picker } from '@react-native-picker/picker';
import { getEvent, updateEvent } from '../../../services/sqliteService';
import { useTheme } from '../../../context/theme';

export default function EditEventScreen() {
  const { colors } = useTheme();
  const { id } = useLocalSearchParams();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [event, setEvent] = useState(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [budget, setBudget] = useState('');
  const [status, setStatus] = useState('Planning');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const fetchEvent = async () => {
    try {
      setLoading(true);
      
      // Convert string ID to number for comparison
      const numericId = parseInt(id);
      const eventData = await getEvent(numericId);
      
      console.log('=== EDIT EVENT DEBUG ===');
      console.log('URL ID:', id, 'Parsed ID:', numericId);
      console.log('Event data:', eventData);
      
      if (!eventData) {
        Alert.alert('Error', `Event with ID ${numericId} not found.`);
        router.back();
        return;
      }

      setEvent(eventData);
      setName(eventData.name || '');
      setDescription(eventData.description || '');
      setBudget(eventData.budget ? eventData.budget.toString() : '');
      setStatus(eventData.status || 'Planning');
      setLocation(eventData.location || '');
      setStartDate(eventData.startDate || '');
      setEndDate(eventData.endDate || '');
    } catch (error) {
      console.error('Error fetching event:', error);
      Alert.alert('Error', 'Could not load event. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Please enter an event name');
      return;
    }

    const numBudget = parseFloat(budget) || 0;
    if (budget && numBudget < 0) {
      Alert.alert('Error', 'Budget must be a positive number');
      return;
    }

    try {
      setSaving(true);

      await updateEvent(parseInt(id), {
        name: name.trim(),
        description: description.trim(),
        budget: numBudget,
        status,
        location: location.trim(),
        startDate: startDate || null,
        endDate: endDate || null,
      });

      Alert.alert('Success', 'Event updated successfully');
      router.back();
    } catch (error) {
      console.error('Error updating event:', error);
      Alert.alert('Error', 'Could not update event. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    fetchEvent();
  }, [id]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={{ flex: 1 }} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
        <Card style={styles.card}>
          <Text style={styles.title}>Edit Event</Text>
          
          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Event Name *</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={name}
              onChangeText={setName}
              placeholder="Enter event name"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={description}
              onChangeText={setDescription}
              placeholder="Enter event description"
              placeholderTextColor={colors.text + '80'}
              multiline
              numberOfLines={3}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Budget (Rs.)</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={budget}
              onChangeText={setBudget}
              placeholder="Enter budget amount"
              placeholderTextColor={colors.text + '80'}
              keyboardType="numeric"
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Status</Text>
            <RNView style={[styles.pickerContainer, { 
              borderColor: colors.border, 
              backgroundColor: colors.card 
            }]}>
              <Picker
                selectedValue={status}
                onValueChange={setStatus}
                style={[styles.picker, { color: colors.text }]}
              >
                <Picker.Item label="Planning" value="Planning" />
                <Picker.Item label="Active" value="Active" />
                <Picker.Item label="Completed" value="Completed" />
                <Picker.Item label="Cancelled" value="Cancelled" />
              </Picker>
            </RNView>
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Location</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={location}
              onChangeText={setLocation}
              placeholder="Enter event location"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>Start Date (YYYY-MM-DD)</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={startDate}
              onChangeText={setStartDate}
              placeholder="2024-12-25"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.inputGroup}>
            <Text style={styles.label}>End Date (YYYY-MM-DD)</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: colors.border, 
                backgroundColor: colors.card,
                color: colors.text 
              }]}
              value={endDate}
              onChangeText={setEndDate}
              placeholder="2024-12-26"
              placeholderTextColor={colors.text + '80'}
            />
          </RNView>

          <RNView style={styles.buttonContainer}>
            <Button
              title="Cancel"
              onPress={() => router.back()}
              variant="outline"
              style={styles.button}
            />
            <Button
              title={saving ? "Saving..." : "Save Changes"}
              onPress={handleSubmit}
              disabled={saving}
              style={styles.button}
            />
          </RNView>
        </Card>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 18,
    marginVertical: 16,
  },
  headerCard: {
    marginHorizontal: 16,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  eventInfo: {
    flex: 1,
    marginRight: 16,
  },
  eventName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  eventDescription: {
    fontSize: 16,
    opacity: 0.7,
    marginBottom: 12,
  },
  eventMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    marginBottom: 8,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 12,
    marginBottom: 4,
  },
  statusText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  locationText: {
    fontSize: 14,
    opacity: 0.7,
  },
  dateInfo: {
    marginTop: 8,
  },
  dateText: {
    fontSize: 14,
    opacity: 0.7,
    marginBottom: 2,
  },
  actionButtons: {
    alignItems: 'flex-end',
  },
  actionButton: {
    marginBottom: 8,
    minWidth: 80,
  },
  statsCard: {
    marginTop: 16,
    marginHorizontal: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    opacity: 0.7,
  },
  expensesCard: {
    marginTop: 16,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  addButton: {
    minWidth: 120,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 14,
    opacity: 0.7,
    marginBottom: 24,
  },
  firstExpenseButton: {
    minWidth: 150,
  },
  card: {
    margin: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  pickerContainer: {
    borderWidth: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  picker: {
    height: 50,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  button: {
    flex: 1,
    marginHorizontal: 8,
  },
});