import AsyncStorage from '@react-native-async-storage/async-storage';

// Simple translation system
const translations = {
  en: {
    // Navigation
    home: 'Home',
    categories: 'Categories', 
    events: 'Events',
    funders: 'Funders',
    expenses: 'Expenses',
    dashboard: 'Dashboard',
    settings: 'Settings',
    backup: 'Backup',
    
    // Common
    add: 'Add',
    edit: 'Edit',
    delete: 'Delete',
    save: 'Save',
    cancel: 'Cancel',
    ok: 'OK',
    error: 'Error',
    success: 'Success',
    loading: 'Loading...',
    
    // Home Screen
    eventFilter: 'Event Filter',
    selectEvent: 'Select Event to View:',
    allEvents: 'All Events',
    generateEventReport: '📄 Generate Event Report',
    addExpense: 'Add Expense',
    viewAll: 'View All',
    selectEventFirst: 'Please select a specific event to generate its report.',
    eventNotFound: 'Selected event not found',
    
    // Settings
    language: 'Language',
    selectLanguage: 'Select Language',
    languageChanged: 'Language changed successfully!',
    about: 'About',
    developer: 'Developer',
    version: 'Version',
    currentVersion: '1.0.2',
    
    // Language Selection
    chooseLanguage: 'Choose your preferred language:',
    languageSelection: 'Language Selection',
    english: 'English',
    sinhala: 'සිංහල',
    
    // Settings Screen
    appName: 'App Name',
    features: 'Features',
    budgetManagement: 'Budget Management',
    eventManagement: 'Event Management',
    pdfReports: 'PDF Reports',
    sqliteDatabase: 'SQLite Database',
    offlineSupport: 'Offline Support',
    dataExportImport: 'Data Export/Import',
    theme: 'Theme',
    contact: 'Contact',
    
    // Budget Summary
    totalBudget: 'Total Budget',
    receivedFund: 'Received Fund',
    spentAmount: 'Spent Amount',
    remainingAmount: 'Remaining Amount',
    
    // Recent Expenses
    recentExpenses: 'Recent Expenses',
    noExpenses: 'No expenses found',
    noExpensesYet: 'No expenses yet',
    addFirstExpense: 'Add your first expense to get started',
    recentExpensesAllEvents: 'Recent Expenses (All Events)',
    
    // Status
    outstanding: 'Outstanding',
    pending: 'Pending',
    received: 'Received',
    spent: 'Spent',
    
    // Dashboard
    reportsDataManagement: 'Reports & Data Management',
    generateReports: 'Generate Reports',
    completeReport: 'Complete Report',
    eventReport: 'Event Report',
    dataManagement: 'Data Management',
    exportData: 'Export Data',
    importData: 'Import Data',
    expenseStatus: 'Expense Status',
    categoryBreakdown: 'Category Breakdown',
    funderBreakdown: 'Funder Breakdown'
  },
  
  si: {
    // Navigation
    home: 'මුල් පිටුව',
    categories: 'කාණ්ඩ',
    events: 'සිදුවීම්',
    funders: 'අරමුදල්කරුවන්',
    expenses: 'වියදම්',
    dashboard: 'පාලක පුවරුව',
    settings: 'සැකසීම්',
    backup: 'උපස්ථ',
    
    // Common
    add: 'එකතු කරන්න',
    edit: 'සංස්කරණය',
    delete: 'මකන්න',
    save: 'සුරකින්න',
    cancel: 'අවලංගු කරන්න',
    ok: 'හරි',
    error: 'දෝෂයක්',
    success: 'සාර්ථකයි',
    loading: 'පූරණය වෙමින්...',
    
    // Home Screen
    eventFilter: 'සිදුවීම් පෙරහන',
    selectEvent: 'බැලීමට සිදුවීමක් තෝරන්න:',
    allEvents: 'සියලු සිදුවීම්',
    generateEventReport: '📄 සිදුවීම් වාර්තාව ජනනය කරන්න',
    addExpense: 'වියදම එකතු කරන්න',
    viewAll: 'සියල්ල බලන්න',
    selectEventFirst: 'කරුණාකර මුලින්ම නිශ්චිත සිදුවීමක් තෝරන්න.',
    eventNotFound: 'තෝරාගත් සිදුවීම සොයා ගත නොහැක',
    
    // Settings
    language: 'භාෂාව',
    selectLanguage: 'භාෂාව තෝරන්න',
    languageChanged: 'භාෂාව සාර්ථකව වෙනස් කරන ලදී!',
    about: 'පිළිබඳව',
    developer: 'සංවර්ධකයා',
    version: 'අනුවාදය',
    currentVersion: '1.0.2',
    
    // Language Selection
    chooseLanguage: 'ඔබේ කැමති භාෂාව තෝරන්න:',
    languageSelection: 'භාෂා තේරීම',
    english: 'English',
    sinhala: 'සිංහල',
    
    // Settings Screen
    appName: 'යෙදුමේ නම',
    features: 'විශේෂාංග',
    budgetManagement: 'අයවැය කළමනාකරණය',
    eventManagement: 'සිදුවීම් කළමනාකරණය',
    pdfReports: 'PDF වාර්තා',
    sqliteDatabase: 'SQLite දත්ත සමුදාය',
    offlineSupport: 'අන්තර්ජාල නොමැතිව සහාය',
    dataExportImport: 'දත්ත නිර්යාත/ආයාත',
    theme: 'තේමාව',
    contact: 'සම්බන්ධතා',
    
    // Budget Summary
    totalBudget: 'මුළු අයවැය',
    receivedFund: 'ලැබුණු අරමුදල',
    spentAmount: 'වියදම් කළ මුදල',
    remainingAmount: 'ඉතිරි මුදල',
    
    // Recent Expenses
    recentExpenses: 'මෑත වියදම්',
    noExpenses: 'වියදම් සොයා ගත නොහැක',
    noExpensesYet: 'තවම වියදම් නැත',
    addFirstExpense: 'ආරම්භ කිරීමට ඔබේ පළමු වියදම එකතු කරන්න',
    recentExpensesAllEvents: 'මෑත වියදම් (සියලු සිදුවීම්)',
    
    // Status
    outstanding: 'ගෙවීමට ඇති',
    pending: 'අපේක්ෂාවේ',
    received: 'ලැබුණු',
    spent: 'වියදම් කළ',
    
    // Dashboard
    reportsDataManagement: 'වාර්තා සහ දත්ත කළමනාකරණය',
    generateReports: 'වාර්තා ජනනය කරන්න',
    completeReport: 'සම්පූර්ණ වාර්තාව',
    eventReport: 'සිදුවීම් වාර්තාව',
    dataManagement: 'දත්ත කළමනාකරණය',
    exportData: 'දත්ත නිර්යාත කරන්න',
    importData: 'දත්ත ආයාත කරන්න',
    expenseStatus: 'වියදම් තත්ත්වය',
    categoryBreakdown: 'කාණ්ඩ විශ්ලේෂණය',
    funderBreakdown: 'අරමුදල්කරු විශ්ලේෂණය'
  }
};

class SimpleI18n {
  constructor() {
    this.currentLanguage = 'en';
    this.listeners = [];
  }

  async init() {
    try {
      const savedLang = await AsyncStorage.getItem('app_language');
      if (savedLang && translations[savedLang]) {
        this.currentLanguage = savedLang;
      }
    } catch (error) {
      console.error('Error loading language:', error);
    }
  }

  t(key) {
    const keys = key.split('.');
    let value = translations[this.currentLanguage];
    
    for (const k of keys) {
      value = value?.[k];
    }
    
    return value || key;
  }

  async changeLanguage(lang) {
    if (translations[lang]) {
      this.currentLanguage = lang;
      try {
        await AsyncStorage.setItem('app_language', lang);
        this.notifyListeners();
        return true;
      } catch (error) {
        console.error('Error saving language:', error);
        return false;
      }
    }
    return false;
  }

  getCurrentLanguage() {
    return this.currentLanguage;
  }

  getAvailableLanguages() {
    return [
      { code: 'en', name: 'English', nativeName: 'English' },
      { code: 'si', name: 'Sinhala', nativeName: 'සිංහල' }
    ];
  }

  addListener(callback) {
    this.listeners.push(callback);
  }

  removeListener(callback) {
    this.listeners = this.listeners.filter(l => l !== callback);
  }

  notifyListeners() {
    this.listeners.forEach(callback => callback(this.currentLanguage));
  }

  async isFirstLaunch() {
    try {
      const hasLaunched = await AsyncStorage.getItem('has_launched_before');
      return !hasLaunched;
    } catch (error) {
      return false;
    }
  }

  async setLaunched() {
    try {
      await AsyncStorage.setItem('has_launched_before', 'true');
    } catch (error) {
      console.error('Error setting launched:', error);
    }
  }
}

export const i18n = new SimpleI18n();
export default i18n;