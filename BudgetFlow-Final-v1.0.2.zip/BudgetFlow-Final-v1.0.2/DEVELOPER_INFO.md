# Developer Information

## 👨‍💻 Developer Profile
**Name:** Dilsan Pathum  
**Email:** pathumpanagoda@gmail.com  
**Role:** Full Stack Mobile App Developer

## 🚀 Project: BudgetFlow
**Description:** Complete expense tracking and budget management application  
**Technology:** React Native, Expo, SQLite  
**Features:** Multi-event management, PDF reports, data export/import

## 📞 Contact
For any inquiries about this project or development services:
- **Email:** pathumpanagoda@gmail.com
- **Project:** BudgetFlow - SQLite Edition