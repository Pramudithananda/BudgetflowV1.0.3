import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';

// Import language files
import en from '../locales/en.json';
import si from '../locales/si.json';

// Initialize i18next
i18next
  .use(initReactI18next)
  .init({
    compatibilityJSON: 'v3',
    lng: 'en', // Default language
    fallbackLng: 'en',
    resources: {
      en: { translation: en },
      si: { translation: si },
    },
    interpolation: {
      escapeValue: false,
    },
  });

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isFirstLaunch, setIsFirstLaunch] = useState(false);
  const [isLanguageReady, setIsLanguageReady] = useState(false);

  useEffect(() => {
    loadLanguagePreference();
  }, []);

  const loadLanguagePreference = async () => {
    try {
      console.log('Loading language preference...');
      const savedLanguage = await AsyncStorage.getItem('user_language');
      const hasLaunchedBefore = await AsyncStorage.getItem('has_launched_before');
      
      console.log('Saved language:', savedLanguage);
      console.log('Has launched before:', hasLaunchedBefore);
      
      if (!hasLaunchedBefore) {
        // First launch - show language selection
        console.log('First launch detected');
        setIsFirstLaunch(true);
        setCurrentLanguage('en'); // Set default
        setIsLanguageReady(true);
      } else if (savedLanguage) {
        // Load saved language
        console.log('Loading saved language:', savedLanguage);
        await changeLanguage(savedLanguage, false);
        setIsLanguageReady(true);
      } else {
        // Default to English
        console.log('Using default language');
        setCurrentLanguage('en');
        setIsLanguageReady(true);
      }
    } catch (error) {
      console.error('Error loading language preference:', error);
      // Fallback to English
      setCurrentLanguage('en');
      setIsLanguageReady(true);
    }
  };

  const changeLanguage = async (languageCode, showAlert = true) => {
    try {
      await i18next.changeLanguage(languageCode);
      setCurrentLanguage(languageCode);
      await AsyncStorage.setItem('user_language', languageCode);
      
      if (showAlert) {
        const { Alert } = require('react-native');
        Alert.alert(
          i18next.t('common.success'),
          i18next.t('settings.languageChanged')
        );
      }
    } catch (error) {
      console.error('Error changing language:', error);
    }
  };

  const completeFirstLaunch = async () => {
    try {
      await AsyncStorage.setItem('has_launched_before', 'true');
      setIsFirstLaunch(false);
    } catch (error) {
      console.error('Error completing first launch:', error);
    }
  };

  const getAvailableLanguages = () => [
    { code: 'en', name: 'English', nativeName: 'English' },
    { code: 'si', name: 'Sinhala', nativeName: 'සිංහල' },
  ];

  const value = {
    currentLanguage,
    changeLanguage,
    isFirstLaunch,
    completeFirstLaunch,
    getAvailableLanguages,
    isLanguageReady,
    t: i18next.t, // Translation function
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export default LanguageContext;