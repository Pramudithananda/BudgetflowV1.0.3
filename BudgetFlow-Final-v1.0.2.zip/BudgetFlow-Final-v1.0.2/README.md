# BudgetFlow - SQLite Edition

Complete expense tracking and budget management app with offline SQLite database.

## 👨‍💻 Developer
**Dilsan Pathum**  
Email: pathumpanagoda@gmail.com

## 📱 About
BudgetFlow is a comprehensive expense management application built with React Native/Expo and SQLite database. Track your expenses, manage budgets, and generate detailed reports - all offline!
