import React from 'react';
import { StyleSheet, View, Alert } from 'react-native';
import { Text } from './Themed';
import Button from './Button';
import Card from './Card';
import { FontAwesome5 } from '@expo/vector-icons';
import { useLanguage } from '../context/language';
import { useTheme } from '../context/theme';

export default function LanguageSelector({ onLanguageSelected }) {
  const { changeLanguage, getAvailableLanguages } = useLanguage();
  const { colors, isDarkMode } = useTheme();
  const languages = getAvailableLanguages();

  const handleLanguageSelect = async (languageCode) => {
    try {
      await changeLanguage(languageCode, false);
      onLanguageSelected && onLanguageSelected(languageCode);
    } catch (error) {
      console.error('Error selecting language:', error);
      Alert.alert('Error', 'Could not change language');
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <FontAwesome5 name="globe" size={48} color={colors.primary} />
        <Text style={[styles.title, { color: colors.text }]}>
          Select Your Language
        </Text>
        <Text style={[styles.subtitle, { color: colors.text }]}>
          ඔබේ භාෂාව තෝරන්න
        </Text>
        <Text style={[styles.description, { color: colors.textSecondary }]}>
          Choose your preferred language:
        </Text>
      </View>

      <View style={styles.languageContainer}>
        {languages.map((language) => (
          <Card key={language.code} style={styles.languageCard}>
            <Button
              title={`${language.nativeName}`}
              onPress={() => handleLanguageSelect(language.code)}
              style={[styles.languageButton, { borderColor: colors.border }]}
              icon={
                <FontAwesome5 
                  name={language.code === 'en' ? 'flag-usa' : 'flag'} 
                  size={20} 
                  color={colors.primary} 
                  style={styles.flagIcon} 
                />
              }
            />
            <Text style={[styles.languageSubtext, { color: colors.textSecondary }]}>
              {language.name}
            </Text>
          </Card>
        ))}
      </View>

      <View style={styles.footer}>
        <Text style={[styles.footerText, { color: colors.textSecondary }]}>
          You can change this later in Settings
        </Text>
        <Text style={[styles.footerText, { color: colors.textSecondary }]}>
          ඔබට මෙය පසුව සැකසීම්වලින් වෙනස් කළ හැක
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 8,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 8,
  },
  languageContainer: {
    width: '100%',
    maxWidth: 300,
  },
  languageCard: {
    marginBottom: 16,
    padding: 8,
  },
  languageButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  flagIcon: {
    marginRight: 12,
  },
  languageSubtext: {
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
  },
  footer: {
    marginTop: 40,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
  },
});