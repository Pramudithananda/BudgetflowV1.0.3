import React from 'react';
import { StyleSheet, View, Alert } from 'react-native';
import { Text } from './Themed';
import Button from './Button';
import Card from './Card';
import { FontAwesome5 } from '@expo/vector-icons';
import { useTheme } from '../context/theme';
import i18n from '../utils/i18n';

export default function SimpleLanguageSelector({ onLanguageSelected }) {
  const { colors } = useTheme();

  const handleLanguageSelect = async (languageCode) => {
    try {
      await i18n.changeLanguage(languageCode);
      await i18n.setLaunched();
      onLanguageSelected && onLanguageSelected(languageCode);
    } catch (error) {
      console.error('Error selecting language:', error);
      Alert.alert('Error', 'Could not change language');
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <FontAwesome5 name="globe" size={48} color={colors.primary} />
        <Text style={[styles.title, { color: colors.text }]}>
          Language Selection
        </Text>
        <Text style={[styles.subtitle, { color: colors.text }]}>
          භාෂා තේරීම
        </Text>
        <Text style={[styles.description, { color: colors.textSecondary }]}>
          Choose your preferred language:
        </Text>
        <Text style={[styles.description, { color: colors.textSecondary }]}>
          ඔබේ කැමති භාෂාව තෝරන්න:
        </Text>
      </View>

      <View style={styles.languageContainer}>
        <Card style={styles.languageCard}>
          <Button
            title="🇺🇸 English"
            onPress={() => handleLanguageSelect('en')}
            style={[styles.languageButton, { borderColor: colors.border }]}
            icon={<FontAwesome5 name="flag-usa" size={20} color={colors.primary} style={styles.flagIcon} />}
          />
        </Card>
        
        <Card style={styles.languageCard}>
          <Button
            title="🇱🇰 සිංහල"
            onPress={() => handleLanguageSelect('si')}
            style={[styles.languageButton, { borderColor: colors.border }]}
            icon={<FontAwesome5 name="flag" size={20} color={colors.primary} style={styles.flagIcon} />}
          />
        </Card>
      </View>

      <View style={styles.footer}>
        <Text style={[styles.footerText, { color: colors.textSecondary }]}>
          You can change this later in Settings
        </Text>
        <Text style={[styles.footerText, { color: colors.textSecondary }]}>
          ඔබට මෙය පසුව සැකසීම්වලින් වෙනස් කළ හැක
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 16,
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 4,
  },
  languageContainer: {
    width: '100%',
    maxWidth: 300,
  },
  languageCard: {
    marginBottom: 16,
    padding: 8,
  },
  languageButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  flagIcon: {
    marginRight: 12,
  },
  footer: {
    marginTop: 40,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
  },
});